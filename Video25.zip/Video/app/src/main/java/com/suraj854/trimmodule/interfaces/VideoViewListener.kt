package com.suraj854.trimmodule.interfaces

interface VideoViewListener {
}