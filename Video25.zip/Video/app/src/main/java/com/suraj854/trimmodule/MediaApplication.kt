package com.suraj854.trimmodule

import android.app.Application
import com.google.firebase.crashlytics.FirebaseCrashlytics

class MediaApplication :Application() {
    override fun onCreate() {
        super.onCreate()

    }
}