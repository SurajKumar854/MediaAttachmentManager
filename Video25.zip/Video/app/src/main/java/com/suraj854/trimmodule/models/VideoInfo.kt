package com.suraj854.trimmodule.models

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import java.io.File
import java.io.Serializable


data class VideoInfo(val duration:Long)
  /*  var videoId: Long = 0
    var videoName = ""
    var authorName = ""
    var description = ""

    //视频全路径,包含视频文件名的路径信息
    var videoPath: String? = null

    //视频所在文件夹的路径
    var videoFolderPath: String? = null
    var createTime: String? = null
    var duration: Long = 0
    var thumbPath: String? = null
    var rotate = 0*/

